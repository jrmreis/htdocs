-- MySQL dump 10.13  Distrib 5.1.73, for redhat-linux-gnu (x86_64)
--
-- Host: 10.19.2.73    Database: updatedeng
-- ------------------------------------------------------
-- Server version	5.6.48-log
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `up_adm_mga`
--

DROP TABLE IF EXISTS `up_adm_mga`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `up_adm_mga` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ativo` tinyint(1) DEFAULT '1',
  `email` varchar(255) DEFAULT NULL,
  `senha` varchar(40) DEFAULT NULL,
  `nome` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `up_adm_mga`
--

LOCK TABLES `up_adm_mga` WRITE;
/*!40000 ALTER TABLE `up_adm_mga` DISABLE KEYS */;
INSERT INTO `up_adm_mga` VALUES (1,1,'jrmreis@gmail.com','1108a23d8f7a0feba7fe66ee25872ac7','JOEL RODRIGUES DE MENDONCA REIS');
/*!40000 ALTER TABLE `up_adm_mga` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `up_contatos`
--

DROP TABLE IF EXISTS `up_contatos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `up_contatos` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `email` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `telefone` varchar(20) COLLATE latin1_general_ci DEFAULT NULL,
  `mensagem` text COLLATE latin1_general_ci,
  `data_contato` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `up_contatos`
--

LOCK TABLES `up_contatos` WRITE;
/*!40000 ALTER TABLE `up_contatos` DISABLE KEYS */;
INSERT INTO `up_contatos` VALUES (1,'dasdas','dasdas@dasdas.com',NULL,'dasdasdas','2015-09-21 12:30:58'),(2,'dsadasd','dasdasdas@dasdas.com',NULL,'dasdasdas','2015-09-21 15:39:20'),(3,'abv','abv@dasdas.com',NULL,'dasdasda','2015-09-21 15:50:56'),(4,'adasdas','dasdas@dasdas.com',NULL,'dasdas','2015-09-21 15:52:09'),(5,'adasdas','dasdas@dasdas.com',NULL,'dasdas','2015-09-21 15:52:16'),(6,'adasdas','dasdas@dasdas.com',NULL,'dasdas','2015-09-21 15:53:18'),(7,'adasdas','dasdas@dasdas.com',NULL,'dasdas','2015-09-21 15:53:26'),(8,'adasdas','dasdas@dasdas.com',NULL,'dasdas','2015-09-21 15:55:20'),(9,'adasdas','dasdas@dasdas.com',NULL,'dasdas','2015-09-21 15:56:17'),(10,'sdasdas','dasdas@dasdas.com',NULL,'dasdsa','2015-09-21 15:57:37'),(11,'teste','teste@teste.com',NULL,'teste','2015-09-21 15:59:00'),(12,'Douglas Iga','douglas@sitevelox.com.br',NULL,'Teste 123','2015-09-24 18:50:20'),(13,'Francisco Valder Batista','bfanciscovalder@yahoo.com.br','55270124','Senhores gestores.Gostaria de fazer parte desta organizaçaõ,tenho experiencia em processamento termico analise de microestrutura,mediçaõ de dureza superficial,analise  quimica dos aços naõ ferroso e ferroso.faso voto de sucesso na diva profissional e pessoal, estou tentando mim recoloca nesta aria  desejavel muito  obrigado por abrir oportunidade.att.f.valder.','2015-11-25 23:14:36'),(14,'Lucas','lucasfur@hotmail.com','19993573004','Sou estudante do quarto ano de engenharia de materiais na UNESP, e tenho como objetivo traçãr minha carreira no seguimento de análise de falhas, gostaria de saber se existe a oportunidade de estagio com vocês, se sim como seria o processo. Obrigado, aguardo resposta.','2016-05-10 00:32:03'),(15,'Mark','','92366822842','5wyYRE https://www.y7YwKx7Pm6OnyJvolbcwrWdoEnRF29pb.com','2016-05-11 21:47:49'),(16,'JimmiXS','','23901686617','uDnwgP https://www.FyLitCl7Pf7kjQdDUOLQOuaxTXbj5iNG.com','2016-08-10 18:52:38'),(17,'Francisco Valder Batista','bfanciscovalder@yahoo.com.br','1155270124','Tenho entenreço de ajuntasse  esta organização,fazemos voto de sucesso na vida profissional e pessoal. ','2016-10-08 11:59:56'),(18,'frances bruzzi','frances.bruzzi@vale.com','31-3833-6784','Bom dia. Gostaria de saber se a Updated ministra treinamento avançado em Análise de Falhas em equipamentos. Trabalho com este foco e já fiz alguns treinamentos, porém gostaria de me reciclar e atualizar com uma empresa consagrada no assunto. \r\nDesde já agradeço e aguardo o retorno.\r\n\r\nAtte,\r\n\r\nFrances Bruzzi','2016-11-10 13:43:39'),(19,'Barnypok','','15359155099','i7QFor https://www.FyLitCl7Pf7ojQdDUOLQOuaxTXbj5iNG.com','2017-01-05 14:59:50'),(20,'Barnypok','','99169654215','WhzM1w https://www.FyLitCl7Pf7ojQdDUOLQOuaxTXbj5iNG.com','2017-01-05 15:00:15'),(21,'Barnypok','','97728298345','CwkpXa https://www.FyLitCl7Pf7ojQdDUOLQOuaxTXbj5iNG.com','2017-01-05 15:00:28'),(22,'Barnypok','','92752704979','CG2GKz https://www.FyLitCl7Pf7ojQdDUOLQOuaxTXbj5iNG.com','2017-01-05 15:00:41'),(23,'Data Link - Softwares P/ Qualidade E Produtividade','vendas@datalink.inf.br','4730286690','Prepare sua empresa para a retomada da economia com estas soluções \r\ncompletas para Qualidade e Produtividade. \r\nSoftwares web e desktop, desenvolvidos para máxima automação \r\nde rotinas, visando redução de custos e melhoria da qualidade e da \r\nprodutividade, a preços acessíveis a qualquer empresa: \r\n \r\n- Controle de documentos; \r\n- Auditorias; \r\n- Controle e Tratamento de Não Conformidades e Melhorias; \r\n- Análises de Riscos e Melhorias; \r\n- Monitoramento Estatístico e Indicadores; \r\n- Controle Estatístico do Processo; \r\n- Controle e Encaminhamento de Reclamações, Sugestões, etc.; \r\n- Inspeção de Produto e Recebimento; \r\n- Registro e Pesquisa de Causas e Soluções de Problemas; \r\n- Programação e Controle de Manutenção; \r\n- Controle de Calibrações de Instrumentos de Medição; \r\n- ERP Completo (compras, vendas, financeiro, estoque, produção, etc.). \r\n \r\nEntre em nosso site (www.datalinksoftwares.com.br), confira as funcionalidades \r\nde cada sistema e solicite-nos um orçamento sem compromisso.','2019-04-02 02:16:12'),(24,'Conceição','conceicao@santosecoutinho.com.br','1194778.8588','Prezados Senhores,\r\n\r\nRegistro de Marcas e Patentes sabe como funciona?\r\n\r\nA sua marca, já está protegida?\r\n\r\nTem certeza que o sinal escolhido por v.sas já não é objeto de patente de terceiros?\r\n\r\nE sobre as suas ideias, todas já estão protegidas como patente?\r\n\r\nNo caso da resposta ser sim eu já tenho.\r\n\r\nNão precisa nos responder.\r\n\r\nCaso não tenha o registro, e quer saber como funciona, consulte-nos.\r\n\r\nEstamos à inteira disposição!!\r\n\r\nAtendimento via whatsapp','2019-06-19 13:44:40'),(25,'Conceição','conceicao@santosecoutinho.com.br','119.47788588','Prezados Senhores,\r\n\r\nRegistro de Marcas e Patentes sabe como funciona?\r\n\r\nA sua marca, já está protegida?\r\n\r\nTem certeza que o sinal escolhido por v.sas já não é objeto de patente de terceiros?\r\n\r\nE sobre as suas ideias, todas já estão protegidas como patente?\r\n\r\nNo caso da resposta ser sim eu já tenho.\r\n\r\nNão precisa nos responder.\r\n\r\nCaso não tenha o registro, e quer saber como funciona, consulte-nos.\r\n\r\nEstamos à inteira disposição!!\r\n\r\nAtendimento via whatsapp','2019-08-27 18:04:59'),(26,'Tammara','tammara.daly@msn.com','(02) 6188 3874','Only here are such low prices\r\n\r\nHow are you?\r\n\r\nYou will be surprised at our low prices. Watch and choose.\r\n\r\nHot Sales 30% :\r\n\r\n- Dresses\r\n- Shirts\r\n- Cellphones & Telecommunications\r\n- Computer, Office, Security\r\n- 360° Video Cameras & Accessories\r\n- Beads & Jewelry Making\r\n- Kitchen Appliances\r\n- Women\\\'s Bags\r\n- Diecasts & Toy Vehicles\r\n- Water Sports\r\n- Beauty & Health\r\n- Bathroom Fixtures\r\n\r\nYou can see even more here: https://tinyurl.com/rcpuf89\r\n\r\nThe best offer on the market. Best price and fast delivery.','2020-04-15 16:47:37'),(27,'ASSOCIAÇÃO BRASIL LÍDERES ORG','comendadoriabrasil@braslider-org.org','1125383416','PREZADO RECEBEMOS SUA INDICAÇÃO E FOI ACEITA, VOCÊ ESTÁ SENDO CONVIDADO AO EXCELÊNCIA E QUALIDADE BRASIL 2020, A REALIZAR-SE EM 03  DE NOVEMBRO DE 2020 NO  ESPORTE CLUBE SÍRIO LIBANES SP - NOMEAÇÃO OFICIAL COM TÍTULO PUBLICADO EM D.O. DIÁRIO OFICIAL! COMO DESTAQUE PROFISSIONAL DO ANO– INCLUINDO A NOMEAÇÃO À: Titulação de COMENDADOR(A) com uso Vitalício! emais : comendadoriabrasil@braslider-org.org  e ou  institutobraslider@gmail.com (11) 2538-3416   www.brasillideres.org Acesse o link abaixo TV RECORD: https://www.youtube.com/watch?v=rp5aMhpi3WI https://www.youtube.com/watch?v=JVhIycbiRU4\r\n','2020-08-26 05:52:29');
/*!40000 ALTER TABLE `up_contatos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `up_fields`
--

DROP TABLE IF EXISTS `up_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `up_fields` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ordem` decimal(10,0) DEFAULT '999',
  `tabela` varchar(100) DEFAULT NULL,
  `titulo` varchar(100) DEFAULT NULL,
  `icon` varchar(100) DEFAULT NULL,
  `folder` varchar(100) DEFAULT NULL,
  `serialize` text,
  `tipo` tinyint(1) DEFAULT '1' COMMENT '0 = Simples; 1 = Automático;',
  `url` varchar(150) DEFAULT NULL COMMENT 'URL caso seja tipo Simples',
  `action` tinyint(1) DEFAULT '0' COMMENT 'Se vai aparecer na Aba Actions',
  `action_url` varchar(200) DEFAULT NULL COMMENT 'Padrão = rel-. Define a URL da Aba Action',
  `format_image` text COMMENT 'Serialize do Formato da Imagem',
  `friend` varchar(200) DEFAULT NULL COMMENT 'O campo que será usado como URL Amigável',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `up_fields`
--

LOCK TABLES `up_fields` WRITE;
/*!40000 ALTER TABLE `up_fields` DISABLE KEYS */;
INSERT INTO `up_fields` VALUES (1,'999','adm_mga','Adminsitradores','icon-key',NULL,'a:4:{i:0;a:3:{s:4:\"tipo\";s:4:\"text\";s:5:\"campo\";s:5:\"email\";s:6:\"titulo\";s:6:\"Email:\";}i:1;a:3:{s:4:\"tipo\";s:8:\"password\";s:5:\"campo\";s:5:\"senha\";s:6:\"titulo\";s:6:\"Senha:\";}i:2;a:3:{s:4:\"tipo\";s:4:\"text\";s:5:\"campo\";s:4:\"nome\";s:6:\"titulo\";s:5:\"Nome:\";}i:3;a:3:{s:4:\"tipo\";s:7:\"boolean\";s:5:\"campo\";s:5:\"ativo\";s:6:\"titulo\";s:6:\"Ativo:\";}}',1,NULL,0,NULL,NULL,NULL),(2,'1','slider','Banner Rotativo','icon-picture','slider','a:6:{i:0;a:4:{s:4:\"tipo\";s:4:\"text\";s:5:\"campo\";s:6:\"titulo\";s:6:\"titulo\";s:8:\"Título:\";s:3:\"max\";s:3:\"250\";}i:1;a:4:{s:4:\"tipo\";s:4:\"text\";s:5:\"campo\";s:9:\"subtitulo\";s:6:\"titulo\";s:10:\"Subtitulo:\";s:3:\"max\";s:3:\"250\";}i:2;a:4:{s:4:\"tipo\";s:4:\"text\";s:5:\"campo\";s:3:\"url\";s:6:\"titulo\";s:4:\"URL:\";s:3:\"max\";s:3:\"250\";}i:3;a:3:{s:4:\"tipo\";s:5:\"image\";s:5:\"campo\";s:6:\"imagem\";s:6:\"titulo\";s:7:\"Imagem:\";}i:4;a:4:{s:4:\"tipo\";s:6:\"select\";s:5:\"campo\";s:6:\"target\";s:6:\"titulo\";s:7:\"Target:\";s:6:\"select\";a:2:{s:5:\"_self\";s:15:\"Na mesma janela\";s:6:\"_blank\";s:8:\"Nova aba\";}}i:5;a:3:{s:4:\"tipo\";s:7:\"boolean\";s:5:\"campo\";s:5:\"ativo\";s:6:\"titulo\";s:6:\"Ativo:\";}}\nTamanho Ideal: 1200x450 px\";}i:3;a:4:{s:4:\"tipo\";s:4:\"text\";s:5:\"campo\";s:3:\"url\";s:6:\"titulo\";s:4:\"URL:\";s:3:\"max\";s:3:\"250\";}i:4;a:4:{s:4:\"tipo\";s:6:\"select\";s:5:\"campo\";s:6:\"target\";s:6:\"titulo\";s:7:\"Target:\";s:6:\"select\";a:2:{s:5:\"_self\";s:15:\"Na mesma janela\";s:6:\"_blank\";s:8:\"Nova aba\";}}i:5;a:3:{s:4:\"tipo\";s:7:\"boolean\";s:5:\"campo\";s:5:\"ativo\";s:6:\"titulo\";s:6:\"Ativo:\";}}\nTamanho Ideal: 1200x450 px\";}i:3;a:4:{s:4:\"tipo\";s:4:\"text\";s:5:\"campo\";s:3:\"url\";s:6:\"titulo\";s:4:\"URL:\";s:3:\"max\";s:3:\"250\";}i:4;a:4:{s:4:\"tipo\";s:6:\"select\";s:5:\"campo\";s:6:\"target\";s:6:\"titulo\";s:7:\"Target:\";s:6:\"select\";a:2:{s:5:\"_self\";s:15:\"Na mesma janela\";s:6:\"_blank\";s:8:\"Nova aba\";}}i:5;a:3:{s:4:\"tipo\";s:7:\"boolean\";s:5:\"campo\";s:5:\"ativo\";s:6:\"titulo\";s:6:\"Ativo:\";}}',1,NULL,1,NULL,'a:1:{i:0;a:5:{i:0;s:6:\"imagem\";i:1;s:8:\"adaptive\";i:2;s:4:\"1200\";i:3;s:3:\"450\";i:4;s:6:\"titulo\";}}',NULL),(3,'2','seo','SEO','icon-magic',NULL,'a:2:{i:0;a:5:{s:4:\"tipo\";s:4:\"text\";s:5:\"campo\";s:6:\"titulo\";s:6:\"titulo\";s:12:\"SEO Título:\";s:3:\"max\";s:2:\"90\";s:4:\"help\";s:145:\"Título exibido nas buscas do Google. Caso não seja preenchido, o sistema adiciona o Nome da Página + Nome da Empresa (Sobre - Nome da Empresa)\";}i:1;a:5:{s:4:\"tipo\";s:4:\"text\";s:5:\"campo\";s:11:\"description\";s:6:\"titulo\";s:16:\"SEO Descrição:\";s:3:\"max\";s:3:\"150\";s:4:\"help\";s:41:\"Descrição exibida nas buscas do Google.\";}}',0,'rel-seo.php',0,NULL,'',NULL),(4,'3','services','Serviços','icon-cogs','services','a:5:{i:0;a:4:{s:4:\"tipo\";s:4:\"text\";s:5:\"campo\";s:5:\"title\";s:6:\"titulo\";s:8:\"Título:\";s:3:\"max\";s:3:\"150\";}i:1;a:4:{s:4:\"tipo\";s:5:\"image\";s:5:\"campo\";s:5:\"image\";s:6:\"titulo\";s:7:\"Banner:\";s:4:\"help\";s:89:\"Caso não seja definido uma imagem padrão será utilizada.<br>Tamanho Ideal: 1200x375 px\";}i:2;a:3:{s:4:\"tipo\";s:7:\"boolean\";s:5:\"campo\";s:6:\"active\";s:6:\"titulo\";s:6:\"Ativo:\";}i:3;a:4:{s:4:\"tipo\";s:4:\"text\";s:5:\"campo\";s:9:\"seo_title\";s:6:\"titulo\";s:12:\"SEO Título:\";s:3:\"max\";s:2:\"90\";}i:4;a:4:{s:4:\"tipo\";s:4:\"text\";s:5:\"campo\";s:15:\"seo_description\";s:6:\"titulo\";s:16:\"SEO Descrição:\";s:3:\"max\";s:3:\"150\";}}',1,NULL,1,NULL,'a:1:{i:0;a:5:{i:0;s:5:\"image\";i:1;s:8:\"adaptive\";i:2;s:4:\"1200\";i:3;s:3:\"375\";i:4;s:5:\"title\";}}','title'),(5,'4','service_content','Serviço Conteúdo','icon-cog','services','a:5:{i:0;a:4:{s:4:\"tipo\";s:3:\"sql\";s:5:\"campo\";s:10:\"service_id\";s:6:\"titulo\";s:10:\"Serviços:\";s:3:\"sql\";a:7:{i:0;s:8:\"services\";i:1;s:2:\"id\";i:2;s:5:\"title\";i:3;s:13:\"deleted = \"0\"\";i:4;s:0:\"\";i:5;s:0:\"\";i:6;s:0:\"\";}}i:1;a:4:{s:4:\"tipo\";s:4:\"text\";s:5:\"campo\";s:5:\"title\";s:6:\"titulo\";s:8:\"Título:\";s:3:\"max\";s:3:\"150\";}i:2;a:3:{s:4:\"tipo\";s:8:\"ckeditor\";s:5:\"campo\";s:4:\"text\";s:6:\"titulo\";s:6:\"Texto:\";}i:3;a:4:{s:4:\"tipo\";s:7:\"spinner\";s:5:\"campo\";s:8:\"sequence\";s:6:\"titulo\";s:25:\"Sequência de Exibição:\";s:4:\"help\";s:17:\"Ordem decrescente\";}i:4;a:3:{s:4:\"tipo\";s:7:\"boolean\";s:5:\"campo\";s:6:\"active\";s:6:\"titulo\";s:6:\"Ativo:\";}}',1,NULL,1,NULL,NULL,'');
/*!40000 ALTER TABLE `up_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `up_images`
--

DROP TABLE IF EXISTS `up_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `up_images` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `page_id` int(11) DEFAULT NULL,
  `pagina` varchar(150) DEFAULT NULL,
  `titulo` varchar(150) DEFAULT NULL,
  `imagem` varchar(150) DEFAULT '',
  `folder` varchar(50) DEFAULT NULL,
  `format_image` text,
  `help` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `up_images`
--

LOCK TABLES `up_images` WRITE;
/*!40000 ALTER TABLE `up_images` DISABLE KEYS */;
/*!40000 ALTER TABLE `up_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `up_newsletters`
--

DROP TABLE IF EXISTS `up_newsletters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `up_newsletters` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `data_contato` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `up_newsletters`
--

LOCK TABLES `up_newsletters` WRITE;
/*!40000 ALTER TABLE `up_newsletters` DISABLE KEYS */;
INSERT INTO `up_newsletters` VALUES (1,'dasdas@dasdas.com','2015-09-21 17:39:37'),(2,'dasdas@dasdas.com','2015-09-21 17:39:42'),(3,'douglas@sitevelox.com.br','2015-09-24 19:14:48'),(4,'marcosfsantos10@hotmail.com','2018-08-31 20:40:13'),(5,'','2020-08-24 19:08:18');
/*!40000 ALTER TABLE `up_newsletters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `up_orcamentos`
--

DROP TABLE IF EXISTS `up_orcamentos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `up_orcamentos` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `cnpj` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `nome` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `email` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `cep` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `cargo` varchar(200) COLLATE latin1_general_ci NOT NULL,
  `mensagem` text COLLATE latin1_general_ci,
  `data_contato` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `up_orcamentos`
--

LOCK TABLES `up_orcamentos` WRITE;
/*!40000 ALTER TABLE `up_orcamentos` DISABLE KEYS */;
INSERT INTO `up_orcamentos` VALUES (1,'02139012093','dasdasdsa','dasda@dasdas.com','123123 - 1231231','Consultor TT','dsadasdasd','2015-09-21 16:05:16'),(2,'12312312','dasdas','dasdas@dasdas.com','123123 - 3123123','Consultor TT','dasdasdasdasda','2015-09-21 16:07:09'),(3,'123','Douglas Iga','douglas@sitevelox.com.br','01452 - 001','Consultor TT','Teste 123','2015-09-24 19:04:02'),(4,'23141234','Joel Reis','jrmreis@gmail.com','05585010 - ','Consultor TT','teste','2015-09-30 20:16:50'),(5,'13279951000193','G.S.R. Tratamento de Superfície e Usinagem LTDA','adm@tatagsr.com.br','15991115 - ','Consultor TT','Calibragem de forno de revenimento','2016-06-20 13:45:16'),(6,'60856820002660','Carlos Alberto dos Santos','carlos.santos@brasimet.com.br','13065 - 195','Consultor TT','Necessitamos TUS e SAT para atendimento às normas AMS2750, CQI-9 e API-6A','2016-08-25 14:10:28'),(7,'','Marcos Ferreira dos Santos ','marcosfsantos10@hotmail.com','53510360 - ','Consultor TT','Boa tarde tenho interesse de comprar um forno de tratamento térmico , quero conhecer quais os produtos e serviços.','2018-08-31 20:44:53'),(8,'23.817.173/0001','Ronaldo Fiorini','metrologia@zmdobrasil.com.br',' - 13347340','Consultor TT','Srs. Temos na empresa fornos de tratamento térmico, e preciso de efetuar teste de TUS e SAT.\r\nQuais dados preciso lhes informar para um orçamento?\r\nEstes serviços prestados pela Updated Eng são acreditados pela RBC?\r\n','2018-12-10 16:32:10'),(9,'88.303.375/0001-71','José Carlos de Oliveira Jr','jose.oliveira@maxiforja.com.br','92420 - 360','Consultor TT','Olá, gostaria de um orçamento para uma avaliação de uniformidade térmica (TUS) em um forno contínuo. A temperatura de trabalho é de cerca de 650°C. \r\nSe tiver alguma dúvida favor entrar em contato por e-mail.','2019-04-09 14:07:22'),(10,'17004901000154','VALBERTO','VALBERTO@ZINCAGEMLINSEL.COM.BR','09980-170 - ','Consultor TT','tenho uma estufa e preciso de teste de TUS\r\n','2019-09-27 17:41:04'),(11,'Tools','Sanchez','nataniel.nogueira28@twinbash.co','98785-769 - 98785769','Consultor AA','','2020-06-30 15:53:42'),(12,'Tools','Sanchez','nataniel.nogueira28@twinbash.co','98785-769 - 98785769','Consultor AA','','2020-06-30 15:54:13'),(13,'Tools','Yango','nataniel.nogueira28@twinbash.co','98785-769 - 98785769','Consultor TT','','2020-06-30 15:54:51'),(14,'Tools','Daron Paul','nataniel.nogueira28@twinbash.co','98785-769 - 98785769','Consultor AA','','2020-06-30 15:55:15'),(15,'Tools','Daron Paul','nataniel.nogueira28@twinbash.co','98785-769 - 98785769','Consultor AA','','2020-06-30 15:55:38'),(16,'Practical Soft Keyboard','Célia Silva','félix.martins@twinbash.co','76257 - 76257','Consultor AA','','2020-06-30 15:59:36'),(17,'Organized','Clement','heitor.silva@twinbash.co','83454-547 - 83454547','Consultor AA','','2020-06-30 16:01:11'),(18,'Organized','Marli','heitor.silva@twinbash.co','83454-547 - 83454547','Consultor AA','','2020-06-30 16:01:30'),(19,'Organized','Clement','heitor.silva@twinbash.co','83454-547 - 83454547','Consultor AA','','2020-06-30 16:01:49'),(20,'Organized','Luis Lopez','heitor.silva@twinbash.co','83454-547 - 83454547','Consultor AA','','2020-06-30 16:02:06'),(21,'Organized','Luis Lopez','heitor.silva@twinbash.co','83454-547 - 83454547','Consultor AA','','2020-06-30 16:02:23'),(22,'','Alex Sandro Cardoso Souza','alexsandro29miguel@gmail.com','06702350 - ','Consultor TT','Aperfeiçoar na minha área, para exercer um ótimo trabalho no mercado.','2020-07-07 02:53:18'),(23,'asdasd','dfas','asdfasdfa@fasdfas','sdff - asdfsdf','Consultor TT','sadfasdf','2020-07-07 14:31:50'),(24,'34057731000195','JOEL RODRIGUES DE MENDONCA REIS','jrmreis@gmail.com','05585-010 - ','Consultor TT','cx','2020-07-07 20:38:44'),(25,'34057731000195','JOEL RODRIGUES DE MENDONCA REIS','jrmreis@gmail.com','05585-010 - asdfsdf','Consultor TT','khjg','2020-07-07 22:27:30'),(26,'','','',' - ','Consultor TT','','2020-07-07 23:29:16'),(27,'','','',' - ','Consultor TT','','2020-07-07 23:46:48'),(28,'34057731000195','JOEL RODRIGUES DE MENDONCA REIS','jrmreis@gmail.com','05585-010 - ','Consultor TT','as','2020-07-08 00:29:12'),(29,'34057731000195','JOEL RODRIGUES DE MENDONCA REIS','jrmreis@gmail.com','05585-010 - ','Consultor TT','kjkj','2020-07-08 00:33:44'),(30,'34057731000195','JOEL RODRIGUES DE MENDONCA REIS','jrmreis@gmail.com','05585-010 - ','Consultor TT','kj','2020-07-08 23:00:10'),(31,'','','',' - ','Consultor TT','','2020-07-08 23:02:41'),(32,'34057731000195','JOEL RODRIGUES DE MENDONCA REIS','jrmreis@gmail.com','05585-010 - ','Consultor TT','ewafa','2020-07-10 12:18:16'),(33,'34057731000195','JOEL RODRIGUES DE MENDONCA REIS','jrmreis@gmail.com','05585-010 - ','Consultor TT','nb','2020-07-10 23:06:08'),(34,'88.303.375/0001-71','MAXIFORJA COMPONENTES AUTOMOTIVOS LTDA','jose.oliveira@maxiforja.com.br','92420-360 - ','Consultor TT','Bom dia.\r\n\r\nMe chamo José Carlos de Oliveira e sou Analista de Processos de tratamento térmico na empresa Maxiforja em Canoas. \r\nEu gostaria de um orçamento para testes de TUS e SAT para um forno de têmpera tipo BIQ, combustol modelo T-10 e para um forno de revenimento Combustol ADLR 8E.','2020-08-03 11:41:53'),(35,'sad','Joel R M Reis','jrmreis@gmail.com','23423 - ','Consultor TT','asdasd','2020-08-24 16:07:21'),(36,'sadsad','Joel R M','jrmreis@gmail.com','23423 - ','Consultor TT','dssd','2020-08-24 19:31:41'),(37,'     ','ASSOCIAÇÃO BRASIL LÍDERES ORG','comendadoriabrasil@braslider-org.org','      -      ','Técnico de Processos','PREZADO RECEBEMOS SUA INDICAÇÃO E FOI ACEITA, VOCÊ ESTÁ SENDO CONVIDADO AO EXCELÊNCIA E QUALIDADE BRASIL 2020, A REALIZAR-SE EM 03  DE NOVEMBRO DE 2020 NO  ESPORTE CLUBE SÍRIO LIBANES SP - NOMEAÇÃO OFICIAL COM TÍTULO PUBLICADO EM D.O. DIÁRIO OFICIAL! COMO DESTAQUE PROFISSIONAL DO ANO– INCLUINDO A NOMEAÇÃO À: Titulação de COMENDADOR(A) com uso Vitalício! emais : comendadoriabrasil@braslider-org.org  e ou  institutobraslider@gmail.com (11) 2538-3416   www.brasillideres.org Acesse o link abaixo TV RECORD: https://www.youtube.com/watch?v=rp5aMhpi3WI https://www.youtube.com/watch?v=JVhIycbiRU4\r\n','2020-08-26 05:52:30'),(38,'     ','ASSOCIAÇÃO BRASIL LÍDERES ORG','comendadoriabrasil@braslider-org.org','      -      ','Técnico de Processos','PREZADO RECEBEMOS SUA INDICAÇÃO E FOI ACEITA, VOCÊ ESTÁ SENDO CONVIDADO AO EXCELÊNCIA E QUALIDADE BRASIL 2020, A REALIZAR-SE EM 03  DE NOVEMBRO DE 2020 NO  ESPORTE CLUBE SÍRIO LIBANES SP - NOMEAÇÃO OFICIAL COM TÍTULO PUBLICADO EM D.O. DIÁRIO OFICIAL! COMO DESTAQUE PROFISSIONAL DO ANO– INCLUINDO A NOMEAÇÃO À: Titulação de COMENDADOR(A) com uso Vitalício! emais : comendadoriabrasil@braslider-org.org  e ou  institutobraslider@gmail.com (11) 2538-3416   www.brasillideres.org Acesse o link abaixo TV RECORD: https://www.youtube.com/watch?v=rp5aMhpi3WI https://www.youtube.com/watch?v=JVhIycbiRU4\r\n','2020-08-26 05:52:31'),(39,'34057731000195','JOEL RODRIGUES DE MENDONCA REIS','jrmreis@gmail.com','05585-010 - ','Consultor TT','redgf','2020-08-26 13:32:59'),(40,'34057731000195','JOEL RODRIGUES DE MENDONCA REIS','jrmreis@gmail.com','05585-010 - ','Consultor TT','sdf','2020-08-26 14:42:08');
/*!40000 ALTER TABLE `up_orcamentos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `up_pages`
--

DROP TABLE IF EXISTS `up_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `up_pages` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `page_id` int(11) DEFAULT NULL,
  `pagina` varchar(150) DEFAULT NULL,
  `titulo` varchar(150) DEFAULT NULL,
  `texto` text,
  `tipo` varchar(30) DEFAULT 'ckeditor',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `up_pages`
--

LOCK TABLES `up_pages` WRITE;
/*!40000 ALTER TABLE `up_pages` DISABLE KEYS */;
INSERT INTO `up_pages` VALUES (1,1,'Sobre','Sobre','<p><strong>A Updated Eng. foi criada com o intuito de oferecer&nbsp; o que existe de mais moderno em tecnologia de aferi&ccedil;&atilde;o, controle e Tunning (ajuste fino) de fornos de Tratamento T&eacute;rmico para a Industria Metal&uacute;rgica.</strong></p>\r\n\r\n<p><strong>Uma das raz&otilde;es para esse empreendimento, foi&nbsp; Eng. Joel Reis, no come&ccedil;o da sua carreira se deparar com contratempos causados por problemas de usinabilidade (rendimento e qualidade da usinagem). Nesse ponto, alocado no Lab. Metalurgia foi constatada a presen&ccedil;a de microconstituintes prejudiciais &agrave; usinagem.</strong></p>\r\n\r\n<p><strong>Aplicando Ishikawa, foi conclu&iacute;do que havia um problema de m&aacute;quina, no caso, o Forno de Tratamento T&eacute;rmico de Recozimento Isot&eacute;rmico.</strong></p>\r\n\r\n<p><strong>Neste caso espec&iacute;fico, uma grande empresa com o sistema de qualidade ISO/ TS 16949 robusto e amadurecido foi vitimada por um problema de m&aacute;quina n&atilde;o detectado pelos operadores, l&iacute;deres e inspetores de qualidade experientes do setor.</strong></p>\r\n\r\n<p><strong>As grandes quest&otilde;es s&atilde;o:&nbsp; se houvesse, naquela &eacute;poca, implanta&ccedil;&atilde;o 100% da CQI-9 o problema poderia ter sido evitado? O custo dessa implanta&ccedil;&atilde;o seria menor ou maior que &ldquo;n&rdquo; paradas de linha? Existem empresas capazes de realiza&ccedil;&atilde;o de TUS e SAT com as exig&ecirc;ncias de sensibilidade e exatid&atilde;o previstas pela norma?</strong></p>\r\n\r\n<p><strong>Para todas essas quest&otilde;es pode-se obter uma &uacute;nica resposta: A Updated Eng. surgiu para oferecer todo subs&iacute;dio para implanta&ccedil;&atilde;o de um sistema capaz de Tratamento T&eacute;rmico, com tecnologia de ultima gera&ccedil;&atilde;o para aferi&ccedil;&atilde;o dos controles de fornos de Tratamento T&eacute;rmico, conhecimento e viv&ecirc;ncia nas &aacute;reas de Laborat&oacute;rio, Produ&ccedil;&atilde;o, Engenharia e Manuten&ccedil;&atilde;o em Plantas de Tratamento T&eacute;rmico.</strong></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n','ckeditor'),(2,0,'Home','Chamada Título','Simulação por Elementos Finitos','text'),(3,0,'Home','Chamada Texto','Resultado de Simulação por Elementos Finitos, onde é possível visualizar a direção, sentido e velocidade das correntes convectivas. Ferramenta que evita o dispendioso método de tentativa e erro para otimização da uniformidade térmica.','textarea'),(4,0,'Home','Texto Sobre','<h3>Atrav&eacute;s de muita pesquisa,&nbsp;experi&ecirc;ncia&nbsp;e investimento, a Updated Eng oferece&nbsp;uma tecnologia de ultima gera&ccedil;&atilde;o para aferi&ccedil;&atilde;o dos controles de fornos de Tratamento T&eacute;rmico de metais.&nbsp;Conhecimento advindo&nbsp;de vivencia nas &aacute;reas de Laborat&oacute;rio, Produ&ccedil;&atilde;o, Engenharia e Manuten&ccedil;&atilde;o em Planta de Tratamento T&eacute;rmico de Metais.</h3>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>A Updated Eng tem&nbsp;como objetivo oferecer presta&ccedil;&atilde;o de servi&ccedil;o especializada, com dedica&ccedil;&atilde;o e qualidade que sempre garantem os melhores resultados, para atender as necessidades e expectativa de cada cliente.</p>\r\n','ckeditor'),(5,0,'Home','Agilidade','Quanto maior a experiência mais rápido fica nos serviços, mantendo sempre um nível alto de qualidade em seus trabalhos.','textarea'),(6,0,'Home','Confiabilidade','Através do conhecimento e tecnologia na área, a Updated Eng tem como objetivo alcançar a satisfação de seus clientes','textarea'),(7,0,'Home','Preços','Produtos com preços compatíveis ao mercado, mas com qualidade e eficiência superior aos concorrentes.','textarea'),(8,2,'Contatos','Telefone','WhatsApp: +55 11 9.9799-2651','text'),(9,2,'Contatos','Email','contato@updatedeng.com.br','text');
/*!40000 ALTER TABLE `up_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `up_seo`
--

DROP TABLE IF EXISTS `up_seo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `up_seo` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pagina` varchar(100) DEFAULT NULL,
  `titulo` varchar(90) DEFAULT NULL,
  `description` text,
  `keywords` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `up_seo`
--

LOCK TABLES `up_seo` WRITE;
/*!40000 ALTER TABLE `up_seo` DISABLE KEYS */;
INSERT INTO `up_seo` VALUES (1,'Página Inicial','Soluções em Metalurgia','Homologação de Fornos de Tratamento Térmico',NULL),(2,'Sobre','','nsw-cdfwou26shol-7a7bvw0lj25644x3g-9kt83vjzherkk7tycw9ez5ly7s2f-6chemuj6-pu0luy6z1t0lxfr3g-kj-8qlnq9uz5p8g641lw-vq102hpejxbcsju4mk7k',NULL),(3,'Serviços','Análise de Falhas','Fractografia, Caracterização Metalúrgica e Simulação por Elementos Finitos',NULL),(4,'Contato',NULL,NULL,NULL),(5,'Orçamento',NULL,NULL,NULL);
/*!40000 ALTER TABLE `up_seo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `up_service_content`
--

DROP TABLE IF EXISTS `up_service_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `up_service_content` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `service_id` int(11) unsigned DEFAULT NULL,
  `title` varchar(250) DEFAULT NULL,
  `text` text,
  `active` tinyint(1) DEFAULT '1',
  `sequence` decimal(10,0) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `service_id` (`service_id`),
  CONSTRAINT `up_service_content_ibfk_1` FOREIGN KEY (`service_id`) REFERENCES `up_services` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `up_service_content`
--

LOCK TABLES `up_service_content` WRITE;
/*!40000 ALTER TABLE `up_service_content` DISABLE KEYS */;
INSERT INTO `up_service_content` VALUES (1,1,'Calibração de Termopares','<p>Utilizando a norma CQI-9, &eacute; realizado a calibra&ccedil;&atilde;o dos termo-sensores, que podem ser termopares ou termo-resist&ecirc;ncias PT-100.<br />\r\nTermopares devem ser calibrados trimestralmente.</p>\r\n\r\n<p>Calibra&ccedil;&atilde;o de Pirometria:</p>\r\n\r\n<p>Termopares (tipo J, K, N, E, T, R, S e B),</p>\r\n\r\n<p>Termoresist&ecirc;ncias (Pt100 IEC, Pt100 JIS, Pt100 SAMA, Pt1000 IEC, Cu10, Ni120),</p>\r\n\r\n<p>sonda zirc&ocirc;nia e sonda lambda (-210 a 2100mV).</p>\r\n\r\n<p>Controladores de temperatura.</p>\r\n\r\n<p>Teste de Uniformidade de Temperatura TUS (Thermal Uniformity Survey) &ndash; exatid&atilde;o &lt; &plusmn; 0,3&deg;C , resolu&ccedil;&atilde;o 0,1&deg;C &ndash; Atende &agrave;s normas do segmento aeron&aacute;utico NADCAP, automotivo CQI-9 que utilizam como referencia a norma de pirometria AMS2750E, que faz parte da categoria &ldquo;Instrumentos de Teste em Campo&rdquo;, em conformidade com a tabela 3 da Norma AMS2750E.</p>\r\n\r\n<p><span style=\"line-height: 1.6em;\">Fornecimento de certificado rastreado RBC.</span></p>\r\n\r\n<p>&nbsp;</p>\r\n',1,'0'),(2,1,'TUS - Thermal Uniformity Survey:','<p><img alt=\"\" src=\"https://www.updatedeng.com.br/files/services/fornos-desenho.jpg\" style=\"width: 372px; height: 249px; float: right;\" />Com base na norma AMS 2750E, &eacute; realizado teste de uniformidade de temperatura em fornos de tratamento t&eacute;rmico com o objetivo de qualificar o forno conforme norma CQI-9 ou API-6A.</p>\r\n\r\n<p>TUS deve ser realizado anualmente ou ap&oacute;s reforma do forno &agrave; qual possa modificar a estabilidade de controle da zona de trabalho.</p>\r\n\r\n<p>Para CQI-9 3&ordf; ed.&nbsp;(Tabela A item A2.4), a toler&acirc;ncia da uniformidade de temperatura para fornos de t&ecirc;mpera deve ser +/- 14&deg;C. Para fornos de revenimento deve ser +/- 11&deg;C.</p>\r\n\r\n<p>Para Fornos Cont&iacute;nuos, esse requisito aplica-se para zona de trabalho qualificada.</p>\r\n\r\n<p>Registros de temperatura(s) para revenimento e processos de endurecimento por precipita&ccedil;&atilde;o devem ser controlados entre +/- 5&deg;C do set point evidenciado pelos registros cont&iacute;nuos dos pir&ocirc;metros.&nbsp;</p>\r\n\r\n<p><span style=\"line-height: 20.8px;\">Registros de temperatura(s) para austenitiza&ccedil;&atilde;o devem ser controlados entre +/- 9&deg;C do set point evidenciado pelos registros cont&iacute;nuos dos pir&ocirc;metros.&nbsp;</span></p>\r\n\r\n<p>Segundo a norma API-6A, ap&ecirc;ndice H, quando a temperatura do forno atingir o set-point, a temperatura em qualquer ponto da zona de trabalho n&atilde;o deve variar mais que +/- 14&deg;C em rela&ccedil;&atilde;o ao set-point de temperatura do forno. Fornos utilizados para revenimento, al&iacute;vio de tens&otilde;es, aging (endurecimento por precipita&ccedil;&atilde;o), quando a temperatura do forno atingir o set-point, a temperatura em qualquer ponto da zona de trabalho n&atilde;o deve variar mais que +/- 8&deg;C em rela&ccedil;&atilde;o ao set-point de temperatura do forno.</p>\r\n\r\n<p><img alt=\"\" src=\"https://www.updatedeng.com.br/files/services/p1a2367qb4bf61fabaq7v831msv4.png\" style=\"width: 800px; height: 396px;\" /></p>\r\n\r\n<p><img alt=\"\" src=\"https://www.updatedeng.com.br/files/pages/p1aef9oojc12jte14la4145d1gr54.png\" style=\"width: 772px; height: 231px;\" /></p>\r\n',1,'0'),(3,1,'SAT','<p>O Teste de acuidade do sistema (SAT) de controle da zona qualificada como zona de trabalho deve ser realizado conforme item A2.3 da Tabela A CQI-9&nbsp;pelo m&eacute;todo de sondagem ou pelo m&eacute;todo comparativo.</p>\r\n\r\n<p><strong>M&eacute;todo por Sondagem A:</strong><br />\r\nToler&acirc;ncia +/- 5&deg;C&nbsp;do controlador em rela&ccedil;&atilde;o ao instrumento de teste:</p>\r\n\r\n<p style=\"margin-left: 160px;\"><img alt=\"\" src=\"C:\\Users\\Joel\\Google Drive\\PJ\\Site\\sat.png\" /><img alt=\"\" src=\"https://www.updatedeng.com.br/files/pages/p1a0g5i2mn4281gno1obn1ppi11vg4.png\" style=\"width: 509px; height: 237px;\" /></p>\r\n\r\n<p><img alt=\"\" src=\"https://www.updatedeng.com.br/files/pages/p1a1kfjbm42gihg7u776610gt4.png\" style=\"width: 800px; height: 132px;\" /></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong style=\"line-height: 20.8px;\">M&eacute;todo por Sondagem B:</strong><br style=\"line-height: 20.8px;\" />\r\n<span style=\"line-height: 20.8px;\">Toler&acirc;ncia +/- 5&deg;C do controlador em rela&ccedil;&atilde;o ao instrumento de teste:</span></p>\r\n\r\n<p style=\"margin-left: 120px;\"><img alt=\"\" src=\"https://www.updatedeng.com.br/files/pages/p1a1kfun2o1vkm1s20hvo1vl81dj94.png\" style=\"width: 527px; height: 237px;\" /></p>\r\n\r\n<p><img alt=\"\" src=\"https://www.updatedeng.com.br/files/pages/p1a1kg0k9h1as91ckmdgi17qcic84.png\" style=\"width: 800px; height: 153px;\" /></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong style=\"line-height: 1.6em;\">M&eacute;todo comparativo:&nbsp;</strong></p>\r\n\r\n<p>Toler&acirc;ncia +/- 1&deg;C do em rela&ccedil;&atilde;o ao indicador, comparando-se com a ultima mensura&ccedil;&atilde;o mensal:</p>\r\n\r\n<p style=\"margin-left: 120px;\"><img alt=\"\" src=\"https://www.updatedeng.com.br/files/pages/p1a1kg6ldblaur0r1r8l9hai84.png\" style=\"width: 527px; height: 237px;\" /></p>\r\n\r\n<p><img alt=\"\" src=\"https://www.updatedeng.com.br/files/pages/p1a1kgaai319ctft21k9c1uj812584.png\" style=\"width: 800px; height: 153px;\" /></p>\r\n',1,'12'),(4,2,'CQI-9','<p>A auditoria interna &eacute; uma ferramenta extremamente importante para preparar a f&aacute;brica para uma auditoria de cliente ou &oacute;rg&atilde;o certificador.</p>\r\n\r\n<p>Por&eacute;m, normas como a CQI-9 visam implementar um m&eacute;todo de trabalho o qual diminui-se o risco, implementando meios para reduzir a probabilidade de eventos indesej&aacute;veis ocorrerem, dessa forma a frequ&ecirc;ncia de pe&ccedil;as n&atilde;o conformes diminua drasticamente</p>\r\n\r\n<p><img alt=\"\" src=\"https://www.updatedeng.com.br/files/pages/p1a0g8guvr10m31nclnjd17eb1bt24.png\" style=\"width: 613px; height: 283px;\" /></p>\r\n\r\n<p>Dessa forma o desperd&iacute;cio de recursos (insumos e m&atilde;o de obra) &eacute; eliminado e o fornecedor de Tratamento T&eacute;rmico pode oferecer um servi&ccedil;o com qualidade e pre&ccedil;o competitivo.</p>\r\n',1,'0'),(7,3,'Estudos de Montagem','<p>Quando existe uma falha em campo, o fator de falha mais intuitivo &eacute; a falha de material.</p>\r\n\r\n<p>Por&eacute;m, na engenharia, &eacute; necess&aacute;rio analisar os fatos. A montagem equivocada pode resultar em falha imediata do componente, apesar do material estar dentro das especifica&ccedil;&otilde;es.</p>\r\n\r\n<p>V&iacute;deo de excesso de contra&ccedil;&atilde;o eixo e mancal.</p>\r\n',1,'0'),(8,3,'Simulação por Elementos Finitos (validação do projeto antes do protótipo).','<p><img alt=\"\" src=\"https://www.updatedeng.com.br/files/services/p1a0t6vd101j5p1o5lh0o412jao4.jpg\" style=\"width: 800px; height: 387px;\" /></p>\r\n\r\n<p><img alt=\"\" src=\"https://www.updatedeng.com.br/files/services/p1a0t6v13odib1pi2kdp1smne6t4.jpg\" style=\"width: 800px; height: 387px;\" /></p>\r\n\r\n<p><img alt=\"\" src=\"https://www.updatedeng.com.br/files/services/p1a4r38doa1c1gjmo8a9m8fpsp4.jpg\" style=\"width: 800px; height: 492px;\" /></p>\r\n',1,'0'),(9,3,'Estudo de caso Elos de Corrente:','<p><img alt=\"\" src=\"https://www.updatedeng.com.br/files/services/p1a0t64biomdd5n4hl4e643t76.jpg\" style=\"width: 800px; height: 364px;\" /></p>\r\n',1,'0'),(10,3,'Engenharia Reversa e adequação do projeto à nova condição de trabalho.','<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%;\">\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"text-align: center;width:50%;\">\r\n			<p><img alt=\"\" src=\"https://www.updatedeng.com.br/files/services/engrenhagem-nova.jpg\" /></p>\r\n\r\n			<p>Engrenagem original &ndash; nova</p>\r\n			</td>\r\n			<td style=\"text-align: center;width:50%;\">\r\n			<p><img alt=\"\" src=\"https://www.updatedeng.com.br/files/services/engrenhagem-desgastada.jpg\" style=\"width: 425px; height: 235px;\" /></p>\r\n\r\n			<p>Mesma engrenagem desgastada</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"text-align: center;width:50%;\">\r\n			<p><img alt=\"\" src=\"https://www.updatedeng.com.br/files/services/modelagem-3d.jpg\" style=\"width: 419px; height: 378px;\" /></p>\r\n\r\n			<p>Modelamento 3D</p>\r\n			</td>\r\n			<td style=\"text-align: center;width:50%;\">\r\n			<p><img alt=\"\" src=\"https://www.updatedeng.com.br/files/services/engrenhagem-desenho.jpg\" style=\"width: 461px; height: 315px;\" /></p>\r\n\r\n			<p>Readequa&ccedil;&atilde;o de projeto, incluindo Tratamento T&eacute;rmico localizado de T&ecirc;mpera por Indu&ccedil;&atilde;o, para aumentar a resist&ecirc;ncia &agrave; abras&atilde;o, sem afetar a ductilidade do n&uacute;cleo da engrenagem, essencial para absorver choques, preservando a engrenagens de trincas.</p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n',1,'0'),(11,4,'Definição de ciclo para T.T. para melhor usinagem','<p>Estudo Microestrutura vs. Usinabilidade.</p>\r\n\r\n<p>Existem microconstituintes que representam um delet&eacute;rio para a opera&ccedil;&atilde;o de usinagem. O Tratamento T&eacute;rmico pode ser respons&aacute;vel por um bom desempenho na usinagem, otimizando a produtividade, aumentando a vida &uacute;til de ferramentas de corte e/ou afia&ccedil;&atilde;o.</p>\r\n\r\n<p>Seguem abaixo exemplos de Micrografias que revelam o hist&oacute;rioco t&eacute;rmico de amostras submetidas &agrave; TT Isot&eacute;rmico deficiente.</p>\r\n\r\n<p><img alt=\"\" src=\"https://www.updatedeng.com.br/files/services/p1a1lka503v15162o19vm1o0bt7f4.jpg\" style=\"width: 800px; height: 639px;\" /></p>\r\n\r\n<p style=\"margin-left: 120px;\"><span style=\"line-height: 1.6em;\">Ferrita, Perlita e Bainita; SAE 4320HM, Mag.1000x</span></p>\r\n\r\n<p style=\"margin-left: 120px;\">&nbsp;</p>\r\n\r\n<p><img alt=\"\" src=\"https://www.updatedeng.com.br/files/services/p1a1lkctr11mhhhr51jeqqdu17254.jpg\" style=\"width: 800px; height: 598px;\" /></p>\r\n\r\n<p style=\"margin-left: 120px;\">Ferrita, Perlita,&nbsp;Bainita e inclus&otilde;es n&atilde;o met&aacute;licas; SAE-4820H, Mag.&nbsp;1000x</p>\r\n\r\n<p style=\"text-align: center;\">&nbsp;</p>\r\n\r\n<p style=\"margin-left: 80px;\"><img alt=\"\" src=\"https://www.updatedeng.com.br/files/services/p1a1lkkl4479ijasrcf12971vaj4.jpg\" style=\"width: 640px; height: 480px; float: left;\" /></p>\r\n\r\n<p style=\"text-align: center;\">&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p style=\"margin-left: 120px;\"><span style=\"line-height: 1.6em;\">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span></p>\r\n\r\n<p style=\"margin-left: 120px;\"><span style=\"line-height: 1.6em;\">&nbsp; &nbsp;Ferrita, Perlita e&nbsp;Bainita DIN 20MnCr5 Mod., Mag. 400x</span></p>\r\n\r\n<p style=\"margin-left: 120px;\">&nbsp;</p>\r\n\r\n<p><img alt=\"\" src=\"https://www.updatedeng.com.br/files/pages/p1a4ottqlbqghkg41eak1c572pc4.png\" style=\"width: 800px; height: 599px;\" /></p>\r\n',1,'0'),(12,4,'Interpretação de Microestrutura para qualificar T.T.','<p><img alt=\"\" src=\"https://www.updatedeng.com.br/files/services/p1a0t6d0pc312113094m1o6u18v14.jpg\" style=\"width: 712px; height: 484px;\" /></p>\r\n\r\n<p><img alt=\"\" src=\"https://www.updatedeng.com.br/files/services/p1a0t6d8is1d8s1nus1k681qfju284.jpg\" style=\"width: 712px; height: 484px;\" /></p>\r\n\r\n<p>Slide de microestrutura.</p>\r\n',0,'1'),(13,4,'Análise de Falhas','<p>Atrav&eacute;s da An&aacute;lise de Falha, &eacute; poss&iacute;vel determinar a causa raiz da falha, retroalimentando o fabricante com informa&ccedil;&otilde;es tais como modo de falha e vida do componente at&eacute; a falha.</p>\r\n\r\n<p>Dessa forma, o fabricante pode avaliar o modo e localiza&ccedil;&atilde;o da falha e se a vida do componente satisfez o projeto inicial, al&eacute;m da possibilidade de atualiza&ccedil;&atilde;o do projeto do componente.</p>\r\n\r\n<p>A An&aacute;lise de Falha &eacute; uma an&aacute;lise interdisciplinar, &agrave; qual conta com o conhecimento e experi&ecirc;ncia em Engenharia de Materiais, conforma&ccedil;&atilde;o mec&acirc;nica, siderurgia, inspe&ccedil;&atilde;o de soldagem, processos de tratamento t&eacute;rmico, termoqu&iacute;mico, tratamento de superf&iacute;cie, controle de qualidade, manuten&ccedil;&atilde;o, projetos mec&acirc;nicos, simula&ccedil;&atilde;o por elementos finitos.</p>\r\n\r\n<p>Principais ferramentas utilizadas para fundamentar a An&aacute;lise de Falha:</p>\r\n\r\n<ol style=\"margin-left: 40px;\">\r\n	<li>Fractografia</li>\r\n	<li>Caracteriza&ccedil;&atilde;o metal&uacute;rgica</li>\r\n	<li>Aplica&ccedil;&atilde;o das restri&ccedil;&otilde;es e cargas no componente atrav&eacute;s de Simula&ccedil;&atilde;o por Elementos Finitos.</li>\r\n</ol>\r\n',1,'2'),(14,4,'Treinamento em Metalurgia e Tratamento Térmico','<p>Visando uma maior participa&ccedil;&atilde;o no mercado, empresas distribuidoras de A&ccedil;o, investem em sua equipe de vendas para torn&aacute;-la mais eficiente e fornecer ao cliente final orienta&ccedil;&otilde;es precisas sobre as op&ccedil;&otilde;es de a&ccedil;os dispon&iacute;veis para atendimento espec&iacute;fico das necessidades do cliente em temas como Metalurgia e Tratamento T&eacute;rmico; seja para uma usinagem de engrenagens e posterior tratamento t&eacute;rmico localizado dos dentes da engrenagem ou um tratamento termoqu&iacute;mico de cementa&ccedil;&atilde;o, por exemplo. Para cada fim, existe um material (liga) adequado(a).</p>\r\n\r\n<p>A Updaded Eng. pode fornecer um treinamento personalizado, que visa fornecer o conhecimento necess&aacute;rio para que a equipe de vendas possa adquirir autonomia em negocia&ccedil;&otilde;es cujo cunho t&eacute;cnico seja uma premissa de um negocia&ccedil;&atilde;o bem sucedida.</p>\r\n\r\n<p>O treinamento padr&atilde;o inclui:&nbsp;</p>\r\n\r\n<ol>\r\n	<li>Classifica&ccedil;&atilde;o dos Metais (revis&atilde;o do conceito):\r\n	<ol style=\"list-style-type:lower-alpha;\">\r\n		<li>A&ccedil;o carbono</li>\r\n		<li>A&ccedil;o ligado</li>\r\n	</ol>\r\n	</li>\r\n	<li>Alotropia do a&ccedil;o &ndash; estruturas cristalinas.</li>\r\n	<li>Lingotamento convencional vs. Lingotamento cont&iacute;nuo.\r\n	<ol style=\"list-style-type:lower-alpha;\">\r\n		<li>Processo de Lingotamento convencional</li>\r\n		<li>Processo de Lingotamento cont&iacute;nuo</li>\r\n		<li>Comparativo, Vantagens e Desvantagens de cada processo.</li>\r\n	</ol>\r\n	</li>\r\n	<li>Metalografia:\r\n	<ol style=\"list-style-type:lower-alpha;\">\r\n		<li>Macrografia</li>\r\n		<li>Micrografia</li>\r\n		<li>Tamanho de Gr&atilde;o</li>\r\n	</ol>\r\n	</li>\r\n</ol>\r\n\r\n<p style=\"margin-left:108.0pt;\">i.Austen&iacute;tico</p>\r\n\r\n<p style=\"margin-left:108.0pt;\">ii.Ferr&iacute;tico</p>\r\n\r\n<ol style=\"list-style-type:lower-alpha;\">\r\n	<li value=\"4\">Ferrita</li>\r\n	<li value=\"5\">Perlita</li>\r\n	<li value=\"6\">Cementita</li>\r\n	<li value=\"7\">Martensita</li>\r\n	<li value=\"8\">Bainita</li>\r\n	<li value=\"9\">Inclus&otilde;es n&atilde;o met&aacute;licas</li>\r\n</ol>\r\n\r\n<ol>\r\n	<li value=\"5\">Diagramas e fatores que os influenciam:\r\n	<ol style=\"list-style-type:lower-alpha;\">\r\n		<li>Ferro-carbono</li>\r\n		<li>Curvas S</li>\r\n		<li>Curvas TTT</li>\r\n	</ol>\r\n	</li>\r\n	<li value=\"6\">Tratamentos T&eacute;rmicos:\r\n	<ol style=\"list-style-type:lower-alpha;\">\r\n		<li>Normaliza&ccedil;&atilde;o</li>\r\n		<li>Recozimento</li>\r\n	</ol>\r\n	</li>\r\n</ol>\r\n\r\n<p style=\"margin-left:108.0pt;\">i.Pleno</p>\r\n\r\n<p style=\"margin-left:108.0pt;\">ii.Esferoidiza&ccedil;&atilde;o</p>\r\n\r\n<ol style=\"list-style-type:lower-alpha;\">\r\n	<li value=\"3\">T&ecirc;mpera</li>\r\n	<li value=\"4\">Mart&ecirc;mpera</li>\r\n	<li value=\"5\">Aust&ecirc;mpera</li>\r\n	<li value=\"6\">T&ecirc;mpera superficial</li>\r\n	<li value=\"7\">Revenimento</li>\r\n</ol>\r\n\r\n<ol>\r\n	<li value=\"7\">Temperabilidade dos A&ccedil;os\r\n	<ol style=\"list-style-type:lower-alpha;\">\r\n		<li>Curva &ldquo;U&rdquo;</li>\r\n		<li>Ensaio Jominy</li>\r\n	</ol>\r\n	</li>\r\n	<li value=\"8\">Severidade do meio de T&ecirc;mpera</li>\r\n	<li value=\"9\">Escalas de Durezas e suas correla&ccedil;&otilde;es</li>\r\n	<li value=\"10\">Revenimento aplicado &agrave; necessidade do cliente</li>\r\n	<li value=\"11\">Material vs. Tratamento T&eacute;rmico vs. Aplica&ccedil;&atilde;o:\r\n	<ol style=\"list-style-type:lower-alpha;\">\r\n		<li>Introdu&ccedil;&atilde;o &agrave; t&ecirc;mpera por indu&ccedil;&atilde;o.</li>\r\n		<li>Introdu&ccedil;&atilde;o &agrave; an&aacute;lise de falhas em campo:</li>\r\n	</ol>\r\n	</li>\r\n</ol>\r\n\r\n<p style=\"margin-left:108.0pt;\">i.Tratamento T&eacute;rmico aplicado em material incorreto</p>\r\n\r\n<p style=\"margin-left:108.0pt;\">ii.Apresenta&ccedil;&atilde;o da Microscopia Eletr&ocirc;nica de Varredura (MEV)</p>\r\n\r\n<p style=\"margin-left:144.0pt;\">&nbsp;</p>\r\n\r\n<p>Dura&ccedil;&atilde;o do treinamento: 16 horas</p>\r\n\r\n<p><img alt=\"Treinamento em loco, na Empresa contratante.\" src=\"	https://www.updatedeng.com.br/files/services/p1aui8rvdo18l41lrdo915j614vv4.jpg\" style=\"width: 448px; height: 336px;\" /></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><img alt=\"\" src=\"	https://www.updatedeng.com.br/files/services/p1aui992dm44b9om18r2d5b6ov4.jpg\" style=\"width: 448px; height: 336px;\" /></p>\r\n',1,'1'),(15,5,'Caracterização de Materiais - FRX','<p><span style=\"font-size:10.0pt;font-family:\">Utiliza&ccedil;&atilde;o de equipamento port&aacute;til, propiciando conveni&ecirc;ncia em determina&ccedil;&atilde;o:</span></p>\r\n\r\n<ul>\r\n	<li><span style=\"font-size:10.0pt;font-family:\">Ligas met&aacute;licas (ferrosas ou n&atilde;o) diretamente em equipamentos de grande porte, dispensando retirada de amostra.&nbsp;</span></li>\r\n	<li><span style=\"font-size:10.0pt;font-family:\"><o:p>Minerais (&uacute;mido ou seco).</o:p></span></li>\r\n</ul>\r\n\r\n<p style=\"font-variant-ligatures: normal;font-variant-caps: normal;orphans: 2;\r\ntext-align:start;widows: 2;-webkit-text-stroke-width: 0px;text-decoration-style: initial;\r\ntext-decoration-color: initial;word-spacing:0px\"><span style=\"font-size: 10pt;\">Diferentemente da an&aacute;lise&nbsp;laboratorial&nbsp;tradicional atrav&eacute;s do espectr&ocirc;metro de emiss&atilde;o &oacute;tica, o qual h&aacute;&nbsp;aplica&ccedil;&atilde;o de arco el&eacute;trico, ocasionando&nbsp;queima da superf&iacute;cie da amostra, al&eacute;m da&nbsp;necessidade&nbsp;de g&aacute;s reativo. Pelo m&eacute;todo FRX a amostra n&atilde;o sofre nenhum dano.</span></p>\r\n\r\n<p style=\"font-variant-ligatures: normal;font-variant-caps: normal;orphans: 2;\r\ntext-align:start;widows: 2;-webkit-text-stroke-width: 0px;text-decoration-style: initial;\r\ntext-decoration-color: initial;word-spacing:0px\"><span style=\"font-size: 13.3333px;\">Equipamento conta com padr&otilde;es de calibra&ccedil;&atilde;o para A&ccedil;o de Baixa Liga, A&ccedil;o Ferramenta, Cobre/Lat&atilde;o/Bronze, Calibra&ccedil;&atilde;o por&nbsp;</span><span style=\"font-size: 13.3333px;\">Par&acirc;metros Fundamentais incluindo metais preciosos.</span></p>\r\n\r\n<p style=\"font-variant-ligatures: normal;font-variant-caps: normal;orphans: 2;\r\ntext-align:start;widows: 2;-webkit-text-stroke-width: 0px;text-decoration-style: initial;\r\ntext-decoration-color: initial;word-spacing:0px\"><span style=\"font-size:10.0pt;\r\nfont-family:\"><img alt=\"\" src=\"	https://www.updatedeng.com.br/files/pages/p1deldma70jn213l621f1n4q1jdt4.png\" style=\"width: 292px; height: 324px;\" />&nbsp;<img alt=\"\" src=\"https://www.updatedeng.com.br/files/services/p1demj20bljjm1bftmp1tbg1g594.png\" style=\"width: 261px; height: 272px;\" /></span></p>\r\n\r\n<p style=\"font-variant-ligatures: normal;font-variant-caps: normal;orphans: 2;\r\ntext-align:start;widows: 2;-webkit-text-stroke-width: 0px;text-decoration-style: initial;\r\ntext-decoration-color: initial;word-spacing:0px\"><span style=\"font-size:10.0pt;\r\nfont-family:\"><o:p></o:p></span></p>\r\n',1,'0');
/*!40000 ALTER TABLE `up_service_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `up_services`
--

DROP TABLE IF EXISTS `up_services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `up_services` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `friend` varchar(150) DEFAULT NULL,
  `title` varchar(150) DEFAULT NULL,
  `image` varchar(150) DEFAULT NULL,
  `active` tinyint(1) DEFAULT '1',
  `deleted` tinyint(1) DEFAULT '0',
  `seo_title` varchar(90) DEFAULT NULL,
  `seo_description` varchar(150) DEFAULT NULL,
  `seo_keywords` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `up_services`
--

LOCK TABLES `up_services` WRITE;
/*!40000 ALTER TABLE `up_services` DISABLE KEYS */;
INSERT INTO `up_services` VALUES (1,'homologacao-de-fornos-de-tratamento-termico-c-1','Homologação de Fornos de Tratamento Térmico CQI-9','',1,0,'Homologação CQI-9','Homologação de Fornos de Tratamento Térmico CQI-9, API 6A e AMS 2750 E',NULL),(2,'auditoria-interna','Auditoria Interna','',1,0,NULL,NULL,NULL),(3,'analise-de-falhas-3','Análise de Falhas','',1,0,'Análise de Falhas','Análise de Falhas, Fractografia, Caracterização Metalúrgica e Simulação por Elementos Finitos',NULL),(4,'consultoria-em-processos-de-tratamento-termic-4','Consultoria em processos de Tratamento Térmico Metalúrgicos','',1,0,'Consultoria em processos de Tratamento Térmico Metalúrgicos','Consultoria em processos de Tratamento Térmico Metalúrgicos',NULL),(5,'caracterizacao-de-materiais-fluorescencia-rx-5','Caracterização de Materiais - Fluorescência RX',NULL,1,0,'Fluorescência RX','análise quantitativa inox geológica PMI sucata FRX liga alumínio bruker',NULL);
/*!40000 ALTER TABLE `up_services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `up_slider`
--

DROP TABLE IF EXISTS `up_slider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `up_slider` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `titulo` varchar(250) DEFAULT NULL,
  `subtitulo` varchar(250) NOT NULL,
  `imagem` varchar(250) DEFAULT NULL,
  `url` varchar(250) DEFAULT NULL,
  `target` varchar(15) DEFAULT '_self',
  `ativo` tinyint(1) DEFAULT '1',
  `data_cadastro` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `up_slider`
--

LOCK TABLES `up_slider` WRITE;
/*!40000 ALTER TABLE `up_slider` DISABLE KEYS */;
INSERT INTO `up_slider` VALUES (1,'HOMOLOGAÇÃO DE FORNOS DE <br/> TRATAMENTO TÉRMICO','Tecnologia de ultima geração para aferição dos  controles de fornos de Tratamento Térmico de metais.','fornos-2-de-tratamento-termico-2-1-1.jpg','https://www.updatedeng.com.br/servico/homologacao-de-fornos-de-tratamento-termico-c-1','_blank',1,'2015-08-03 22:17:38'),(2,'HOMOLOGAÇÃO <br/> CQI-9, API6-A, AMS2750-E','Tecnologia de ultima geração para aferição dos controles de fornos de Tratamento Térmico de metais.','fornos-2-de-tratamento-termico-1-2.jpg','https://www.updatedeng.com.br/servico/homologacao-de-fornos-de-tratamento-termico-c-1','_self',1,'2015-09-21 03:22:15');
/*!40000 ALTER TABLE `up_slider` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `up_states`
--

DROP TABLE IF EXISTS `up_states`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `up_states` (
  `id` int(2) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `uf` varchar(10) NOT NULL,
  `nome` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `up_states`
--

LOCK TABLES `up_states` WRITE;
/*!40000 ALTER TABLE `up_states` DISABLE KEYS */;
INSERT INTO `up_states` VALUES (01,'AC','Acre'),(02,'AL','Alagoas'),(03,'AM','Amazonas'),(04,'AP','Amapá'),(05,'BA','Bahia'),(06,'CE','Ceará'),(07,'DF','Distrito Federal'),(08,'ES','Espírito Santo'),(09,'GO','Goiás'),(10,'MA','Maranhão'),(11,'MG','Minas Gerais'),(12,'MS','Mato Grosso do Sul'),(13,'MT','Mato Grosso'),(14,'PA','Pará'),(15,'PB','Paraíba'),(16,'PE','Pernambuco'),(17,'PI','Piauí'),(18,'PR','Paraná'),(19,'RJ','Rio de Janeiro'),(20,'RN','Rio Grande do Norte'),(21,'RO','Rondônia'),(22,'RR','Roraima'),(23,'RS','Rio Grande do Sul'),(24,'SC','Santa Catarina'),(25,'SE','Sergipe'),(26,'SP','São Paulo'),(27,'TO','Tocantins');
/*!40000 ALTER TABLE `up_states` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'updatedeng'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-08-26 12:18:12
